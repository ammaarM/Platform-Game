package game;

import city.cs.engine.DebugViewer;

import javax.swing.*;

public class Game {
    private GameWorld world;
    private GameView view;

    public Game() {
        // world
        GameWorld world = new GameWorld();

        //view
        view = new GameView(world, 900, 506);
        view.setZoom(20);

        //The program will now detect mouse Clicks
        view.addMouseListener(new MouseHandler(world, view));
        //Listener allows the hollow knight model to be controlled.
        HollowKnightController controller = new HollowKnightController(world.getHollowKnight());
        view.addKeyListener(controller);

        MouseHandler mh = new MouseHandler(world, view);
        view.addMouseListener(mh);
        view.addMouseListener(new Focus(view));

        // Frame
        final JFrame frame = new JFrame("Hollow Knight Start");
        frame.add(view);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        frame.setResizable(false);
        frame.pack();
        frame.setVisible(true);

        // debugger
        //JFrame debugView = new DebugViewer(world, 900, 506);
        // draw a 1-metre grid over the view
        //view.setGridResolution(1);

        System.out.println("||  Controls:                             ||");
        System.out.println("||  Use A and D to move left and right    ||");
        System.out.println("||  Use SpaceBar to jump                  ||");
        System.out.println("||  Use J to attack                       ||");
        System.out.println("||  ----------------------------------    ||");
        System.out.println("||  Attack the Mob to kill it             ||");
        System.out.println("||  If you touch the Mob you will die     ||");
        world.start();
    }

    public static void main(String[] args) {
        new Game();
    }
}
